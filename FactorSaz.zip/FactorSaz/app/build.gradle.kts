plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

val ksFile = System.getenv("KEYSTORE_FILE")?.let { file(it) }?.takeIf { it.exists() }

android {
    namespace = "com.factorsaz.app"
    compileSdk = 34
    defaultConfig { applicationId = "com.factorsaz.app"; minSdk = 29; targetSdk = 34; versionCode = 6; versionName = "1.5" }
    buildFeatures { buildConfig = true }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }

    flavorDimensions += "store"
    productFlavors {
        create("bazaar") {
            dimension = "store"
            buildConfigField("String", "STORE_RSA", "\"${System.getenv("BAZAAR_RSA") ?: ""}\"")
            buildConfigField("String", "FULL_SKU", "\"full_version\"")
        }
        create("myket") {
            dimension = "store"
            buildConfigField("String", "STORE_RSA", "\"${System.getenv("MYKET_RSA") ?: ""}\"")
            buildConfigField("String", "FULL_SKU", "\"full_version\"")
        }
    }
    signingConfigs {
        create("store") {
            if (ksFile != null) {
                storeFile = ksFile; storeType = "pkcs12"
                storePassword = System.getenv("KEYSTORE_PASSWORD"); keyAlias = "factorsaz"; keyPassword = System.getenv("KEYSTORE_PASSWORD")
            }
        }
    }
    buildTypes {
        release { signingConfig = if (ksFile != null) signingConfigs.getByName("store") else signingConfigs.getByName("debug") }
    }
}
dependencies {
    implementation("androidx.webkit:webkit:1.11.0")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-ktx:1.9.2")
    "bazaarImplementation"("com.github.cafebazaar.Poolakey:poolakey:2.2.0")
}
