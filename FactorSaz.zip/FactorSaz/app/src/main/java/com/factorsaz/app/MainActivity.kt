package com.factorsaz.app

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.Base64
import android.view.View
import android.webkit.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.FileProvider
import androidx.webkit.WebViewAssetLoader
import java.io.File

class MainActivity : ComponentActivity() {
    private lateinit var web: WebView
    private var fileCb: ValueCallback<Array<Uri>>? = null
    private var billing: StoreBilling? = null
    private val prefs by lazy { getSharedPreferences("lic", 0) }
    private val chooser = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(r.resultCode, r.data)); fileCb = null
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        window.statusBarColor = Color.parseColor("#0B4BBF")
        createWeb()
        billing = createBilling(this) { pushLicense(it) }
        billing?.start()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun createWeb() {
        web = WebView(this); web.overScrollMode = View.OVER_SCROLL_NEVER; setContentView(web)
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this)).build()
        web.settings.apply { javaScriptEnabled = true; domStorageEnabled = true; allowFileAccess = false }
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest) = loader.shouldInterceptRequest(r.url)
            override fun onRenderProcessGone(v: WebView, d: RenderProcessGoneDetail): Boolean {
                runOnUiThread { try { web.destroy() } catch (e: Exception) {}; createWeb() }
                return true
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(w: WebView, cb: ValueCallback<Array<Uri>>, p: FileChooserParams): Boolean {
                fileCb?.onReceiveValue(null); fileCb = cb
                chooser.launch(p.createIntent()); return true
            }
        }
        web.addJavascriptInterface(Bridge(), "AndroidBridge")
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    override fun onDestroy() { billing?.stop(); super.onDestroy() }

    private fun pushLicense(full: Boolean) {
        prefs.edit().putBoolean("full", full).apply()
        web.evaluateJavascript("window.onLicense && window.onLicense($full)", null)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        web.evaluateJavascript("(function(){var s=document.getElementById('sheet');if(s&&!s.hidden){s.hidden=true;return 1}return 0})()") {
            if (it != "1") finish()
        }
    }

    inner class Bridge {
        private fun clean(n: String) = n.replace(Regex("[\\\\/:*?\"<>|]"), "_")

        @JavascriptInterface fun isDemoApp() = true
        @JavascriptInterface fun isFull() = prefs.getBoolean("full", false)
        @JavascriptInterface fun buy() { runOnUiThread { billing?.buy() } }

        @JavascriptInterface fun setStatusColor(hex: String) {
            runOnUiThread { try { window.statusBarColor = Color.parseColor(hex) } catch (e: Exception) {} }
        }

        @JavascriptInterface fun saveFile(name: String, mime: String, b64: String) {
            val bytes = Base64.decode(b64, Base64.DEFAULT)
            val v = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, clean(name))
                put(MediaStore.Downloads.MIME_TYPE, mime)
                put(MediaStore.Downloads.RELATIVE_PATH, "Download/Factor")
            }
            contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)?.let { u ->
                contentResolver.openOutputStream(u)?.use { it.write(bytes) }
            }
        }

        @JavascriptInterface fun shareFile(name: String, mime: String, b64: String) {
            val f = File(File(cacheDir, "share").apply { mkdirs() }, clean(name))
            f.writeBytes(Base64.decode(b64, Base64.DEFAULT))
            val u = FileProvider.getUriForFile(this@MainActivity, "$packageName.fp", f)
            val i = Intent(Intent.ACTION_SEND).apply {
                type = mime; putExtra(Intent.EXTRA_STREAM, u); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            runOnUiThread { startActivity(Intent.createChooser(i, "ارسال فاکتور")) }
        }
    }
}
