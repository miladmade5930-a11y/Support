package com.factorsaz.app

interface StoreBilling {
    fun start()
    fun buy()
    fun stop()
}
