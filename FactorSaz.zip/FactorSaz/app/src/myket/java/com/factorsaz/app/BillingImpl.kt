package com.factorsaz.app

import android.widget.Toast
import androidx.activity.ComponentActivity

// TODO: خرید درون‌برنامه‌ای مایکت هنوز پیاده نشده. تا آن موقع این نسخه را منتشر نکن.
fun createBilling(a: ComponentActivity, onFull: (Boolean) -> Unit): StoreBilling = object : StoreBilling {
    override fun start() {}
    override fun buy() { Toast.makeText(a, "خرید از مایکت هنوز فعال نشده است", Toast.LENGTH_LONG).show() }
    override fun stop() {}
}
