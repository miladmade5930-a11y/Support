package com.factorsaz.app

import android.widget.Toast
import androidx.activity.ComponentActivity
import ir.cafebazaar.poolakey.Connection
import ir.cafebazaar.poolakey.Payment
import ir.cafebazaar.poolakey.config.PaymentConfiguration
import ir.cafebazaar.poolakey.config.SecurityCheck
import ir.cafebazaar.poolakey.request.PurchaseRequest

fun createBilling(a: ComponentActivity, onFull: (Boolean) -> Unit): StoreBilling = object : StoreBilling {
    private val check = if (BuildConfig.STORE_RSA.isBlank()) SecurityCheck.Disable
        else SecurityCheck.Enable(rsaPublicKey = BuildConfig.STORE_RSA)
    private val payment = Payment(context = a, config = PaymentConfiguration(localSecurityCheck = check))
    private var conn: Connection? = null

    override fun start() {
        conn = payment.connect {
            connectionSucceed {
                payment.getPurchasedProducts {
                    querySucceed { list -> onFull(list.any { it.productId == BuildConfig.FULL_SKU }) }
                    queryFailed { }
                }
            }
            connectionFailed { }
            disconnected { }
        }
    }

    override fun buy() {
        payment.purchaseProduct(
            registry = a.activityResultRegistry,
            request = PurchaseRequest(productId = BuildConfig.FULL_SKU, payload = "factorsaz")
        ) {
            purchaseSucceed { onFull(true) }
            purchaseCanceled { }
            purchaseFailed { Toast.makeText(a, "خرید انجام نشد. دوباره امتحان کن", Toast.LENGTH_LONG).show() }
            failedToBeginFlow { Toast.makeText(a, "بازار باز نشد. مطمئن شو بازار نصب و واردش شده‌ای", Toast.LENGTH_LONG).show() }
        }
    }

    override fun stop() { conn?.disconnect() }
}
